package br.rhuan.teste0001;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class tela_inicial extends AppCompatActivity {
    private Button btCadastrar;
    private Button btConsultar;
    private Button btExcluir;
    
    
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_inicial);
        getSupportActionBar().hide();
        inicializarComponentes();

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(tela_inicial.this, cadastrar_usuario.class);
                startActivity(i);
            }
        });


        btConsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(tela_inicial.this, consultar_usuario.class);
                startActivity(i);
            }
        });

        btExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(tela_inicial.this, excluir_usuario.class);
                startActivity(i);
            }
        });



    }

    private void inicializarComponentes() {
        btCadastrar = findViewById(R.id.btCadastrar);
        btConsultar = findViewById(R.id.btConsultar);
        btExcluir = findViewById(R.id.btExcluir);
    }
}