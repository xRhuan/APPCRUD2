package br.rhuan.teste0001;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static String nome = "BancoDados.db";
    private static int versao = 7;

    public DBHelper (Context context){
        super(context, nome,null,versao);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    String str = "CREATE TABLE usuario(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,nome VARCHAR(80) UNIQUE NOT NULL, sexo VARCHAR(9) NOT NULL, dataNasc DATE NOT NULL, email VARCHAR(50) NOT NULL, celular VARCHAR(17) NOT NULL, cep VARCHAR(9) NOT NULL, numeroResidencia INT NOT NULL, bairro VARCHAR(50) NOT NULL, cidade VARCHAR(50) NOT NULL , uf VARCHAR(2) NOT NULL);";
    db.execSQL(str);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS usuario;");
        onCreate(db);
    }
    public long criarUsuario(String nome, String sexo, String dataNasc, String email,
                             String celular, String cep, String numeroResidencia, String bairro, String cidade, String uf){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nome",nome);
        cv.put("sexo",sexo);
        cv.put("dataNasc",dataNasc);
        cv.put("email",email);
        cv.put("celular",celular);
        cv.put("cep",cep);
        cv.put("numeroResidencia",numeroResidencia);
        cv.put("bairro",bairro);
        cv.put("cidade",cidade);
        cv.put("uf",uf);
        long result = db.insert("usuario",null,cv);

        return result;
    }

    public Pessoa consultarUsuario(String nome){
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM usuario WHERE nome = ?", new String[]{ nome });

        if(cursor.getCount() <= 0) {
            return null;
        }

        cursor.moveToNext();

        Pessoa p = new Pessoa();

        // 0 ---> ID
        // 1 ---> Nome
        p.setSexo(cursor.getString(2));
        p.setDataNasc(cursor.getString(3));
        p.setEmail(cursor.getString(4));
        p.setCelular(cursor.getString(5));
        p.setCep(cursor.getString(6));
        p.setNumeroResidencia(cursor.getString(7));
        p.setBairro(cursor.getString(8));
        p.setCidade(cursor.getString(9));
        p.setUf(cursor.getString(10));

        return p;

    }

    public String editarUsuario(String nome, String sexo, String dataNasc, String email, String celular, String cep, String numeroResidencia, String bairro, String cidade, String uf){
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT id FROM usuario WHERE nome = ?", new String[]{ nome });

        if(cursor.getCount() <= 0) {
            return null;
        }

        cursor.close();

        ContentValues cv = new ContentValues();
        cv.put("nome",nome);
        cv.put("sexo",sexo);
        cv.put("dataNasc",dataNasc);
        cv.put("email",email);
        cv.put("celular",celular);
        cv.put("cep",cep);
        cv.put("numeroResidencia",numeroResidencia);
        cv.put("bairro",bairro);
        cv.put("cidade",cidade);
        cv.put("uf",uf);
        db.update("usuario", cv, "nome = ?", new String[]{nome});

        return "OK";

    }

    public String deletarUsuario(String nome) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT id FROM usuario WHERE nome = ?", new String[]{ nome });

        if(cursor.getCount() <= 0) {
            return null;
        }

        cursor.close();
        db.delete("usuario", "nome = ?",new String[]{nome});

        return "OK";
    }

}
