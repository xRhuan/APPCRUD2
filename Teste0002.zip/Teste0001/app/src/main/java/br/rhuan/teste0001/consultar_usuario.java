package br.rhuan.teste0001;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class consultar_usuario extends AppCompatActivity {

    private EditText edtNome, edtDataNasc, edtEmail, edtCelular, edtCep, edtNumeroResidencia, edtBairro, edtCidade, edtUf;
    private RadioGroup rgSexo;
    private RadioButton rbFeminino;
    private RadioButton rbMasculino;
    private Button btConsultar;
    private Button btAtualizar;
    private RadioButton rbSexo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultar_usuario);
        getSupportActionBar().hide();
        inicializarComponentes();
        DBHelper db = new DBHelper(this);
        btConsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = edtNome.getText().toString();

                Pessoa pessoa = db.consultarUsuario(nome);
                if(pessoa == null) {
                    Toast.makeText(consultar_usuario.this, "Não foi encontrado nenhum usuário com o nome informado, magrão.", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (pessoa.getSexo().equals("Masculino")) {
                        rbMasculino.toggle();
                    } else {
                        rbFeminino.toggle();
                    }

                    edtDataNasc.setText(pessoa.getDataNasc());
                    edtEmail.setText(pessoa.getEmail());
                    edtCelular.setText(pessoa.getCelular());
                    edtCep.setText(pessoa.getCep());
                    edtNumeroResidencia.setText(pessoa.getNumeroResidencia());
                    edtBairro.setText(pessoa.getBairro());
                    edtCidade.setText(pessoa.getCidade());
                    edtUf.setText(pessoa.getUf());
                }
            }
        });

        btAtualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nome = edtNome.getText().toString();
                String dataNasc = edtDataNasc.getText().toString();
                String email = edtEmail.getText().toString();
                String celular = edtCelular.getText().toString();
                String cep = edtCep.getText().toString();
                String numeroResidencia = edtNumeroResidencia.getText().toString();
                String bairro = edtBairro.getText().toString();
                String cidade = edtCidade.getText().toString();
                String uf = edtUf.getText().toString();
                int selectedId = rgSexo.getCheckedRadioButtonId();

                String sexo = "";
                if(selectedId != -1) {
                    rbSexo = findViewById(selectedId);
                    sexo = rbSexo.getText().toString();
                }
                if(nome.equals("")) {
                    Toast.makeText(consultar_usuario.this, "Informe um Nome", Toast.LENGTH_SHORT).show();
                }else if (sexo.equals("")){
                    Toast.makeText(consultar_usuario.this, "Informe um Sexo", Toast.LENGTH_SHORT).show();
                }else if (dataNasc.equals("")){
                    Toast.makeText(consultar_usuario.this, "Informe uma Data", Toast.LENGTH_SHORT).show();
                }else if (email.equals("")){
                    Toast.makeText(consultar_usuario.this, "Informe um E-mail", Toast.LENGTH_SHORT).show();
                }else if (celular.equals("")){
                    Toast.makeText(consultar_usuario.this, "Informe um Celular", Toast.LENGTH_SHORT).show();
                }else if (cep.equals("")){
                    Toast.makeText(consultar_usuario.this, "Informe um Cep", Toast.LENGTH_SHORT).show();
                }else if (numeroResidencia.equals("")){
                    Toast.makeText(consultar_usuario.this, "Informe um Numero da Residência", Toast.LENGTH_SHORT).show();
                }else if (bairro.equals("")){
                    Toast.makeText(consultar_usuario.this, "Informe uma Bairro", Toast.LENGTH_SHORT).show();
                }else if (cidade.equals("")){
                    Toast.makeText(consultar_usuario.this, "Informe uma Cidade", Toast.LENGTH_SHORT).show();
                }else if (uf.equals("")){
                    Toast.makeText(consultar_usuario.this, "Informe uma Uf", Toast.LENGTH_SHORT).show();
                }else {
                    try {
                        String res = db.editarUsuario(nome, sexo, dataNasc, email, celular, cep, numeroResidencia, bairro, cidade, uf);
                        if (res.equals("OK")) {
                            Toast.makeText(consultar_usuario.this, "Alteração efetuada com sucesso.", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }catch(Exception error) {
                        Toast.makeText(consultar_usuario.this, "Não há ninguém com o nome informado cadastrado.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void inicializarComponentes() {
        edtNome = (EditText) findViewById(R.id.edtNomeConsulta);
        edtDataNasc = (EditText)findViewById(R.id.edtDataNascConsulta);
        edtEmail = (EditText)findViewById(R.id.edtEmailConsulta);
        edtCelular = (EditText)findViewById(R.id.edtCelularConsulta);
        edtCep = (EditText)findViewById(R.id.edtCepConsulta);
        edtNumeroResidencia = (EditText)findViewById(R.id.edtNumeroResidenciaConsulta);
        edtBairro = (EditText)findViewById(R.id.edtBairroConsulta);
        edtCidade = (EditText)findViewById(R.id.edtCidadeConsulta);
        edtUf = (EditText)findViewById(R.id.edtUfConsulta);
        rgSexo = (RadioGroup) findViewById(R.id.rgSexoConsulta);
        rbFeminino = (RadioButton) findViewById(R.id.rbFemininoConsulta);
        rbMasculino = (RadioButton) findViewById(R.id.rbMasculinoConsulta);
        btConsultar = (Button) findViewById(R.id.btConsultar2);
        btAtualizar = (Button) findViewById(R.id.btAtualizar);

    }
}